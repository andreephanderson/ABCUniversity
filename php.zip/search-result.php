<?php
	session_start();
	require_once "database.php";
	require_once "mahasiswa.php";

	$db = new Mahasiswa();
	if(isset($_SESSION["is_login_admin"])){
		$searchResult = $db->searchMahasiswa($_GET['searchbox']);
		
		echo "<div align='left'>";
		echo "<h1>Search Result Mahasiswa</h1>";
		echo "<table border='1' align='left'>";
		echo "<tr>";
		echo "<th>No</th>";
		echo "<th>Nomor Registrasi</th>";
		echo "<th>Nama Lengkap</th>";
		echo "<th>Email</th>";
		echo "</tr>";
		$no = 0;
		foreach ($searchResult as $e) {
		$no++;
		echo "<tr>";
		echo "<td>" . $no . "</td>";
		echo "<td>" . $e['noregistrasi'] . "</td>";
		echo "<td>" . $e['namalengkap'] . "</td>";
		echo "<td>" . $e['email'] . "</td>";
		echo "</tr></table>";
	}
	echo "</div><br>";
	echo "<p><a class='btn btn-success' href='index-for-admin.php'>Back</a><p>";
}
?>

<html>
	<head>
		<title>Search Result Mhs</title>
	</head>

	<body>

	</body>
</html>
