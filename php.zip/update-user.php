<?php
	session_start();
	require_once "database.php";
	require_once "mahasiswa.php";

	$db = new Mahasiswa();
	if(isset($_SESSION["is_login_admin"])){
		$updateID = $db->updateUser($_GET['updateboxUser']);
		

		echo "<div align='left'>";
		echo "<h1>Update User</h1>";
		echo "<form action='index-for-admin.php' method='POST'>";
		foreach ($updateID as $e) {
		echo "<p class='font-size-1'>ID User yang akan anda Update bernomor " . $e['id'] . "</p>";
		echo "<table><tr>";
		echo "<td><p class='font-size-1'>ID</p></td><td>&nbsp;</td><td><input type='text' name='updateiduser' value='" . $e['id'] . "' readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Lengkap</p></td><td>&nbsp;</td><td><input type='text' name='updatenamalengkapuser' value='" . $e['namalengkap'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Jabatan</p></td><td>&nbsp;</td><td><input type='text' name='updatejabatanuser' value='" . $e['jabatan'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Alamat Rumah</p></td><td>&nbsp;</td><td><input type='text' name='updatealamatuser' value='" . $e['alamat'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nomor Telepon</p></td><td>&nbsp;</td><td><input type='text' name='updatenoteleponuser' value='" . $e['notelepon'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Email</p></td><td>&nbsp;</td><td><input type='email' name='updateemailuser' value='" . $e['email'] . "'></td>";
		echo "<tr><td colspan='3'></td><td>&nbsp;</td><td><input type='submit' value='Submit'></td>";
		echo "</tr></table>";
	}
	echo "</div><br>";
	echo "</form>";
	echo "<p><a class='btn btn-success' href='index-for-admin.php'>Back</a><p>";
}
?>

<html>
	<head>
		<title>Update Data User</title>
		<style type="text/css">
	
		.font-size-1{
    		font-size: 14pt;
		}
		</style>
	</head>

	<body>

	</body>
</html>