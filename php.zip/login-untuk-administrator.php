<?php
	session_start();
	require_once "database.php";
	require_once "mahasiswa.php";

	if ($_POST) {
	$email = $_POST["email"];
	$password = $_POST["password"];

	$db = mysqli_connect("localhost", "root", "", "ABCUniversity") or die("gagal");
	$databaseConnect = new Mahasiswa();
	//mencegah sql injection
	$email = $db->real_escape_string($email);
	$password = $db->real_escape_string($password);
	$nama = $databaseConnect->dataNamaUser($email);

	$query = "SELECT * FROM administrator WHERE email = '$email' AND password = '$password'";
	$result = $db->query($query) or  die($db->error);
	$login_success = ($result->num_rows == 1);


	
	if ($login_success) {
		//buat session is_login
		$_SESSION["is_login_admin"] = true;
		//buat cookies
		setcookie("namalengkap", Administrator, time() + 3600); //nama cookie,isi cookie, expired
		//redirect
		header("Location: index-for-admin.php");
		exit();
	} 
	else{
		echo "<script>alert('Wrong username or password');</script>";
	}
}
?>

<html>
	<head>
		<title>Login Administrator</title>
		<h1>Login</h1>
		<style type="text/css">
	
		.margin-left-220{
    		margin-left: 220px;
		}
		</style>
	</head>
	</head>

	<body>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<form action="login-untuk-administrator.php" method="POST">
			<table>
				<tr>
					<td>Email</td>
					<td>&nbsp;</td>
					<td><input type="email" name="email"></td>
					</tr>
					<tr>
					<td>Password</td>
					<td>&nbsp;</td>
					<td><input type="password" name="password"></td>
					</tr>
					<tr>
					<td colspan="3">
						<input class="btn btn-success margin-left-220" type="submit" name="submit" value="Login">
					</td>
					</tr>
			</table>
		</form>
	</body>
</html>