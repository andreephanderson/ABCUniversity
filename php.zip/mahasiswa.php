<?php
	class Mahasiswa extends Database {
		private $table_name = "mahasiswa";
		private $table_name2 = "user";

		function insert($namalengkap, $asalsekolah, $asalprovinsi, $alamatrumah, $nomortelepon, $namaayah, $namaibu, $nilaiun, $email, $password) {
			$namalengkap = $this->sanitize($namalengkap);
			$asalsekolah = $this->sanitize($asalsekolah);
			$asalprovinsi = $this->sanitize($asalprovinsi);
			$alamatrumah = $this->sanitize($alamatrumah);
			$nomortelepon = $this->sanitize($nomortelepon);
			$namaayah = $this->sanitize($namaayah);
			$namaibu = $this->sanitize($namaibu);
			$nilaiun = $this->sanitize($nilaiun);
			$email = $this->sanitize($email);
			$password = $this->sanitize($password);

			$query = "INSERT INTO " . $this->table_name . "(namalengkap, asalsekolah, asalprovinsi, alamatrumah, notelepon, namaayah, namaibu, nilaiun, email, password) " . 
													"VALUES (" . "'$namalengkap', " .
																 "'$asalsekolah', " .
																 "'$asalprovinsi', " .
																 "'$alamatrumah'," .
																 "'$nomortelepon'," . 
																 "'$namaayah'," .
																 "'$namaibu'," .
																 "'$nilaiun'," .
																 "'$email'," .
																 "'$password'" . ")";
			$result = $this->execute($query) or die ($this->error());
			return $result;
		}

		function insert_user($namalengkap, $jabatan, $alamat, $notelepon, $email, $password) {
			$namalengkap = $this->sanitize($namalengkap);
			$jabatan = $this->sanitize($jabatan);
			$alamat = $this->sanitize($alamat);
			$notelepon = $this->sanitize($notelepon);
			$email = $this->sanitize($email);
			$password = $this->sanitize($password);

			$query = "INSERT INTO " . $this->table_name2 . "(namalengkap, jabatan, alamat, notelepon, email, password) " . 
													"VALUES (" . "'$namalengkap', " .
																 "'$jabatan', " .
																 "'$alamat'," .
																 "'$notelepon'," . 
																 "'$email'," .
																 "'$password'" . ")";
			$result = $this->execute($query) or die ($this->error());
			return $result;
		}

		function login1 ($email, $password) {
			$email = $this->sanitize($email);
			$query = "SELECT id, password FROM " . $this->table_name .
					" WHERE email = '" . $email . "'";
			$result = $this->execute($query) or die($this->error());
			$row = $result->fetch_array();
			if (password_verify($password, $row['password'])) {
				return $row['id'];
			}
			else {
				return -1;
			}
		}

		function dataNamaUser ($email) {
			$email = $this->sanitize($email);
			$query = "SELECT namalengkap FROM " . $this->table_name2 .
					" WHERE email = '" . $email . "'";
			$result = $this->execute($query) or die($this->error());
			$row = $result->fetch_array();
			return $result;
		}

		function select_data_mahasiswa($email, $password) {
			$query = "SELECT * FROM " . $this->table_name . " WHERE email = '" . $email . "' AND password = '" . $password . "'";
			$result = $this->execute($query);
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function select_all_mahasiswa() {
			$query = "SELECT * FROM " . $this->table_name;
			$result = $this->execute($query);
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function select_all_user() {
			$query = "SELECT * FROM " . $this->table_name2;
			$result = $this->execute($query);
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function deleteUser ($id, $email) {
			$query = "DELETE FROM " . $this->table_name2 .
					" WHERE id = '" . $id . "' AND  email = '" . $email . "'";
			$result = $this->execute($query) or die($this->error());
			return $result;
		}

		function deleteMahasiswa ($noregistrasi, $email) {
			$query = "DELETE FROM " . $this->table_name .
					" WHERE noregistrasi = '" . $noregistrasi . "' AND  email = '" . $email . "'";
			$result = $this->execute($query) or die($this->error());
			return $result;
		}

		function searchMahasiswa($namalengkap) {
			$query = "SELECT noregistrasi , namalengkap, email FROM " . $this->table_name .
					" WHERE namalengkap = '" . $namalengkap . "'";
			$result = $this->execute($query) or die($this->error());
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function searchUser($namalengkap) {
			$query = "SELECT id , namalengkap, email FROM " . $this->table_name2 .
					" WHERE namalengkap = '" . $namalengkap . "'";
			$result = $this->execute($query) or die($this->error());
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function updateMahasiswa($noregistrasi) {
			$query = "SELECT * FROM " . $this->table_name .
					" WHERE noregistrasi = '" . $noregistrasi . "'";
			$result = $this->execute($query) or die($this->error());
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function updateDataMahasiswa ($noregistrasi,$namalengkap, $asalsekolah, $asalprovinsi, $alamatrumah, $nomortelepon, $namaayah, $namaibu, $nilaiun, $email) {
			$query = "UPDATE " . $this->table_name .
					" SET namalengkap = '" . $namalengkap . "', asalsekolah = '" . $asalsekolah . "', asalprovinsi = '" . $asalprovinsi . "' alamatrumah = '" . $alamatrumah . "', notelepon = '" . $nomortelepon . "',namaayah = '" . $namaayah . "', namaibu = '" . $namaibu . "', nilaiun = '" . $nilaiun . "', email = '" . $email . "' WHERE noregistrasi='" . $noregistrasi . "'";
			$result = $this->execute($query) or die($this->error());
			return $result;
		}

		function updateUser($id) {
			$query = "SELECT * FROM " . $this->table_name2 .
					" WHERE id = '" . $id . "'";
			$result = $this->execute($query) or die($this->error());
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}

		function updateDataUser ($id,$namalengkap, $jabatan, $alamat, $notelepon, $email) {
			$query = "UPDATE " . $this->table_name2 .
					" SET namalengkap = '" . $namalengkap . "', jabatan = '" . $jabatan . "', alamat = '" . $alamat . "', notelepon = '" . $nomortelepon . "', email = '" . $email . "' WHERE id='" . $id . "'";
			$result = $this->execute($query) or die($this->error());
			return $result;
		}

		function loginMahasiswa($email, $password) {
			$query = "SELECT * FROM " . $this->table_name .
					" WHERE email = '" . $email . "' AND password = '" . $password . "'";
			$result = $this->execute($query) or die($this->error());
			$retval = array();
			while ($row = $result-> fetch_array()) {
				array_push($retval, $row);
			}
			return $retval;
		}
	}
?> 