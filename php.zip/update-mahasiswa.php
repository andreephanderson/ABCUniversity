<?php
	session_start();
	require_once "database.php";
	require_once "mahasiswa.php";

	$db = new Mahasiswa();
	if(isset($_SESSION["is_login_admin"])){
		$updateID = $db->updateMahasiswa($_GET['updatebox']);
		

		echo "<div align='left'>";
		echo "<h1>Update Mahasiswa</h1>";
		echo "<form action='index-for-admin.php' method='POST'>";
		foreach ($updateID as $e) {
		echo "<p class='font-size-1'>Nomor Registrasi yang akan anda Update bernomor " . $e['noregistrasi'] . "</p>";
		echo "<table><tr>";
		echo "<td><p class='font-size-1'>Nomor Registrasi</p></td><td>&nbsp;</td><td><input type='text' name='updatenoregistrasi' value='" . $e['noregistrasi'] . "' readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Lengkap</p></td><td>&nbsp;</td><td><input type='text' name='updatenamalengkap' value='" . $e['namalengkap'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Asal Sekolah</p></td><td>&nbsp;</td><td><input type='text' name='updateasalsekolah' value='" . $e['asalsekolah'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Asal Provinsi</p></td><td>&nbsp;</td><td><input type='text' name='updateasalprovinsi' value='" . $e['asalprovinsi'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Alamat Rumah</p></td><td>&nbsp;</td><td><input type='text' name='updatealamatrumah' value='" . $e['alamatrumah'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nomor Telepon</p></td><td>&nbsp;</td><td><input type='text' name='updatenotelepon' value='" . $e['notelepon'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Ayah</p></td><td>&nbsp;</td><td><input type='text' name='updatenamaayah' value='" . $e['namaayah'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Ibu</p></td><td>&nbsp;</td><td><input type='text' name='updatenamaibu' value='" . $e['namaibu'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nilai UN</p></td><td>&nbsp;</td><td><input type='text' name='updatenilaiun' value='" . $e['nilaiun'] . "'></td></tr>";
		echo "<tr><td><p class='font-size-1'>Email</p></td><td>&nbsp;</td><td><input type='email' name='updateemail' value='" . $e['email'] . "'></td>";
		echo "<tr><td colspan='3'></td><td>&nbsp;</td><td><input type='submit' value='Submit'></td>";
		echo "</tr></table>";
	}
	echo "</div><br>";
	echo "</form>";
	echo "<p><a class='btn btn-success margin-left-100' href='index-for-admin.php'>Back</a><p>";
}
?>

<html>
	<head>
		<title>Update Data Mahasiswa</title>
		<style type="text/css">
	
		.font-size-1{
    		font-size: 14pt;
		}
		.margin-left-100{
    		margin-left: 100px;
		}
		</style>
	</head>

	<body>

	</body>
</html>