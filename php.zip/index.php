<?php
	session_start();
	require_once "database.php";
	require_once "mahasiswa.php";

	$db = new Mahasiswa();



		

	if(isset($_SESSION["is_login"])){
	echo "Welcome, " . $_COOKIE["namalengkap"];
	echo"<br>";
	echo "<a href= 'logout.php'>Logout</a>";
	$datadiri = $db->select_data_mahasiswa($_POST['email'], $_POST['password']);
	foreach ($datadiri as $e) {
		echo "<h1>Data Anda :</h1><table><tr>";
		echo "<td><p class='font-size-1'>Nomor Registrasi</p></td><td>&nbsp;</td><td><input type='text' name='updatenoregistrasi' value='" . $e['noregistrasi'] . "' readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Lengkap</p></td><td>&nbsp;</td><td><input type='text' name='updatenamalengkap' value='" . $e['namalengkap'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Asal Sekolah</p></td><td>&nbsp;</td><td><input type='text' name='updateasalsekolah' value='" . $e['asalsekolah'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Asal Provinsi</p></td><td>&nbsp;</td><td><input type='text' name='updateasalprovinsi' value='" . $e['asalprovinsi'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Alamat Rumah</p></td><td>&nbsp;</td><td><input type='text' name='updatealamatrumah' value='" . $e['alamatrumah'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nomor Telepon</p></td><td>&nbsp;</td><td><input type='text' name='updatenotelepon' value='" . $e['notelepon'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Ayah</p></td><td>&nbsp;</td><td><input type='text' name='updatenamaayah' value='" . $e['namaayah'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nama Ibu</p></td><td>&nbsp;</td><td><input type='text' name='updatenamaibu' value='" . $e['namaibu'] . "'readonly></td></tr>";
		echo "<tr><td><p class='font-size-1'>Nilai UN</p></td><td>&nbsp;</td><td><input type='text' name='updatenilaiun' value='" . $e['nilaiun'] . "'readonly></td></tr>";
			echo "<tr><td><p class='font-size-1'>Email</p></td><td>&nbsp;</td><td><input type='email' name='updateemail' value='" . $e['email'] . "'readonly></td>";
			echo "</tr></table>";
			}
		}
	else {
	header("Location: login.php"); //redirect ke login.php
	
	}
	

	
?>

<html>
	<head>
		<title>Welcome to Univ. ABC</title>
		
	</head>

	<body>
	</body>

	

</html>