<?php
	require_once("database.php");//require_once "database.php"
	require_once "mahasiswa.php";

if ($_POST){
	$namalengkap = $_POST['namalengkap'];
	$asalsekolah = $_POST['asalsekolah'];
	$asalprovinsi = $_POST['asalprovinsi'];
	$alamatrumah = $_POST['alamatrumah'];
	$nomortelepon = $_POST['nomortelepon'];
	$namaayah = $_POST['namaayah'];
	$namaibu = $_POST['namaibu'];
	$nilaiun = $_POST['nilaiun'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password2 = $_POST['password2'];

	if($password != $password2){
		echo "<script>alert('Mismatch password');</script>";
	}
	else{
		$db = new Mahasiswa();
		if($db->insert($namalengkap, $asalsekolah, $asalprovinsi, $alamatrumah, $nomortelepon, $namaayah, $namaibu, $nilaiun, $email, $password)){
			echo "<script>alert('Registered');</script>";
			header ("Location: index-for-user.php");
		}
		else{
			echo "<script>alert('Failed to register!');</script>";
			header ("Location: index-for-user.php");
		}
	}
}
?>

<html>
	<head>
		<title>Add New Mhs</title>
		<h1>ADD New Mahasiswa</h1>
	</head>

	<body>
	<table>
	<form action="register.php" method="POST">

	<tr>
	<td>Nama Lengkap</td>
	<td>&nbsp;</td>
	<td><input type="text" name="namalengkap"></td>
	</tr>

	<tr>
	<td>Asal Sekolah</td>
	<td>&nbsp;</td>
	<td><input type="text" name="asalsekolah"></td>
	</tr>

	<tr>
	<td>Asal provinsi</td>
	<td>&nbsp;</td>
	<td><input type="text" name="asalprovinsi"></td>
	</tr>

	<tr>
	<td>Alamat Rumah</td>
	<td>&nbsp;</td>
	<td><input type="text" name="alamatrumah"></td>
	</tr>

	<tr>
	<td>Nomor Telepon</td>
	<td>&nbsp;</td>
	<td><input type="text" name="nomortelepon"></td>
	</tr>

	<tr>
	<td>Nama Orang tua</td>
	<td>&nbsp;</td>
	<td></td>
	</tr>

	<tr>
	<td>Nama Ayah</td>
	<td>&nbsp;</td>
	<td><input type="text" name="namaayah"></td>
	</tr>

	<tr>
	<td>Nama Ibu</td>
	<td>&nbsp;</td>
	<td><input type="text" name="namaibu"></td>
	</tr>

	<tr>
	<td>Nilai rata-rata UN</td>
	<td>&nbsp;</td>
	<td><input type="text" name="nilaiun"></td>
	</tr>

	<tr>
	<td>Email</td>
	<td>&nbsp;</td>
	<td><input type="email" name="email"></td>
	</tr>

	<tr>
	<td>Password (Untuk login nantinya)</td>
	<td>&nbsp;</td>
	<td><input type="password" name="password"></td>
	</tr>

	<tr>
	<td>Retype Password</td>
	<td>&nbsp;</td>
	<td><input type="password" name="password2"></td>
	</tr>

	<tr>
	<td colspan="2"> </td>
	<td>&nbsp;</td>
	<td><input type="submit" name="submit" value="Register"></td>
	</tr>

	</table></form>
	</body>

	

</html>