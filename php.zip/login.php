

<html>
	<head>
		<title>Login</title>

		<style type="text/css">

	.margin-left-400{
    margin-left: 400px;
	}
	.margin-left-20{
    margin-left: 20px;
	}
	.margin-top-40{
    margin-top: 40px;
    margin-bottom: 15px;
	}
	.margin-top-10{
    margin-top: 10px;
	}
	.font-size-1{
		font-size: 16pt;
	}
	.margin-left-550{
    margin-left: 550px;
	}

	</style>
	</head>
				<p align="center" class="margin-top-40"><img src="Welcome.jpg" alt="Selamat Datang di Official Website Universitas ABC" name="Welcome" width="600" height="300" border="0"></p>
        <div id="pilihan_login">

				   <a href="login-untuk-mahasiswa.php" ><img src="mahasiswa.jpg" onMouseOut="this.src='mahasiswa.jpg'" onMouseOver="this.src='mahasiswa-hov.jpg'" alt="Login Mahasiswa" name="login_mahasiswa" width="160" height="65" border="0" class="rad margin-left-400"></a>
				   <a href="login-untuk-user.php" ><img src="User.jpg" onMouseOut="this.src='User.jpg'" onMouseOver="this.src='User-hov.jpg'" alt="Login User" name="login_user" width="160" height="65" border="0" class="rad margin-left-20"></a>
				   <a href="login-untuk-administrator.php" ><img src="Admin.jpg" onMouseOut="this.src='Admin.jpg'" onMouseOver="this.src='Admin-hov.jpg'" alt="Login Administrator" name="login_administrator" width="160" height="65" border="0" class="rad margin-left-20"></a>
		</div>  
		<p align="center" class="margin-top-10"><img src="pembatas-login-register.jpg" name="pembatas" width="800" height="3" border="0"></p>
		
	</div>
	<body>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<p class="margin-left-550 font-size-1">Belum Register ?
	<a class="btn btn-success" href="register.php" type="button">Register</a></p>


</html>