<?php
	class Database {
		private $conn;

		function __construct() {
			$this->conn = mysqli_connect("localhost", "root", "");
			mysqli_select_db($this->conn, "ABCUniversity");
		}

		function execute($query) {
			$result = $this->conn->query($query);
			return $result;
		}

		function getdatetime() {
			return date('Y-m-d H:i:s');
		}

		function sanitize($str) {
			return mysqli_real_escape_string($this->conn, $str);
		}

		function error() {
			return $this->conn->error;
		}
	}
?>