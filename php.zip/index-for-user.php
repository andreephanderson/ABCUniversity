<?php
	session_start();
	require_once "database.php";
	require_once "mahasiswa.php";

	$db = new Mahasiswa();

	if(isset($_SESSION["is_login_user"])){
		echo "<form action=search-result.php method='GET'>";
	echo "<p>Welcome, User"  . "<input class='margin-left-50' type='text' name='searchbox' placeholder='Name Lengkap. Ex: Andree Phanderson'><input type='submit' class='btn btn-info margin-left-10' value='Search Mahasiswa'><a class='margin-left-100' href= 'logout.php'>Logout</a></p>";
	echo "</form>";
	}
	else {
	header("Location: login.php"); //redirect ke login.php
		
	}

	if(isset($_POST['updatenoregistrasi']) & isset($_POST['updatenamalengkap']) & isset($_POST['updateasalsekolah']) & isset($_POST['updateasalprovinsi']) & isset($_POST['updatealamatrumah']) & isset($_POST['updatenotelepon']) & isset($_POST['updatenamaayah']) & isset($_POST['updatenamaibu']) & isset($_POST['updatenilaiun']) & isset($_POST['updateemail']))
	{
		$nomorregistrasi = $_POST['updatenoregistrasi'];
		$namalengkap = $_POST['updatenamalengkap'];
		$asalsekolah = $_POST['updateasalsekolah'];
		$asalprovinsi = $_POST['updateasalprovinsi'];
		$alamatrumah = $_POST['updatealamatrumah'];
		$nomortelepon = $_POST['updatenotelepon'];
		$namaayah = $_POST['updatenamaayah'];
		$namaibu = $_POST['updatenamaibu'];
		$nilaiun = $_POST['updatenilaiun'];
		$email = $_POST['updateemail'];

		$db->updateDataMahasiswa($nomorregistrasi, $namalengkap, $asalsekolah, $asalprovinsi, $alamatrumah, $nomortelepon, $namaayah, $namaibu, $nilaiun, $email);
		echo "<script>alert('You just updated an Account with Registration Number =  " . $nomorregistrasi . "');</script>";		 
	}

	if(isset($_GET['noregistrasi']) & isset($_GET['email'])){
		echo "<script>alert('You just deleted " . $_GET['email'] . "account');</script>";
		$db->deleteMahasiswa($_GET['noregistrasi'], $_GET['email']);		 
	}
?>

<html>
	<head>
		<title>Index</title>
		<style type="text/css">
		.font-size-1{
    		font-size: 25pt;
		}
		.font-size-2{
			font-size: 15pt;
		}
		.margin-left-50{
    		margin-left: 50px;
		}
		.margin-left-10{
    		margin-left: 10px;
		}
		.margin-left-100{
    		margin-left: 100px;
		}
		.margin-left-551{
    		margin-left: 551px;
		}
		</style>
		<h1>Index</h1>
	</head>

	<body align="center">
	<form action=update-mahasiswa-user.php method='GET'>
	<p class="font-size-1" align="center">Mahasiswa<a class="btn btn-info margin-left-100 font-size-2" href="add-mahasiswa-user.php">Add</a><input class='margin-left-50' type='text' name='updatebox' placeholder='Nomor Registrasi'><input type='submit' class='btn btn-success' value='Update'></p>
	</form>
	<form action="index-for-admin.php" method="POST">
		<?php
	$selectMahasiswaAndUser = $db->select_all_mahasiswa();
	?>
<table border="1" align="center">
<tr>
	<th>No</th>
	<th>Nama Lengkap</th>
	<th>Asal sekolah</th>
	<th>Asal Provinsi</th>
	<th>Alamat Rumah</th>
	<th>Nomor Telepon</th>
	<th>Nama Ayah</th>
	<th>Nama Ibu</th>
	<th>Nilai UN</th>
	<th>Email</th>
	<th>Delete</th>
</tr>
	<?php
	$no = 0;
	foreach ($selectMahasiswaAndUser as $e) {
		$no++;
		echo "<tr>";
		echo "<td>" . $no . "</td>";
		echo "<td>" . $e['namalengkap'] . "</td>";
		echo "<td>" . $e['asalsekolah'] . "</td>";
		echo "<td>" . $e['asalprovinsi'] . "</td>";
		echo "<td>" . $e['alamatrumah'] . "</td>";
		echo "<td>" . $e['notelepon'] . "</td>";
		echo "<td>" . $e['namaayah'] . "</td>";
		echo "<td>" . $e['namaibu'] . "</td>";
		echo "<td>" . $e['nilaiun'] . "</td>";
		echo "<td>" . $e['email'] . "</td>";
		echo "<td> <a href='./index-for-user.php?noregistrasi=" . $e['noregistrasi'] . "&email=" . $e['email'] . "'>Delete</a></td>";
		echo "</tr>";
	}
?>
</table>

	</form>
	</body>

	

</html>