<?php
	if ($_POST) {
	$email = $_POST["email"];
	$password = $_POST["password"];

	$db = mysqli_connect("localhost", "root", "", "ABCUniversity") or die("gagal");

	//mencegah sql injection
	$email = $db->real_escape_string($email);
	$password = $db->real_escape_string($password);

	$query = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
	$result = $db->query($query) or  die($db->error);

	$login_success = ($result->num_rows == 1);
	

	if ($login_success) {
		return view('welcome');
	}
		
	else{
		echo "<script>alert('Wrong username or password');</script>";
	}
}
?>


<html>
	<head>
		<title>Login Mahasiswa</title>

		<style type="text/css">
	
		.margin-left-220{
    		margin-left: 220px;
		}
		</style>
	</head>

	<body background="ABC_Building_South_Bank.jpg">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<div class="container">
	<form class="form-signin" action="/loginMahasiswa" method="POST">
	<?php echo csrf_field(); ?>

        <h2 class="form-signin-heading">Login</h2>
        <input type="email" name="email" class="form-control" placeholder="Email address" required autofocus>
        <input type="password" name="password" class="form-control" placeholder="Password" required>
        <div class="checkbox">
          <label>
            <input type="checkbox" value="remember-me"> Remember me
          </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
      </form>
      </div>
	</body>
</html>