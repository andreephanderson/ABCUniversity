<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UsersController extends Controller
{
	public function index(){
		$users = [
    	'0' => [
    		'first_name' => 'Andree',
    		'last_name' => 'Phanderson',
    		'location' => 'Jakarta'
    		],
    	'1' => [
    		'first_name' => 'Stephanie',
    		'last_name' => 'Budianto',
    		'location' => 'Jakarta'
    		]
    	];
    	return view('admin.users.index');
	}  

	public function create(){
		return view('admin.users.create');
	}



	public function registerSuccess(Request $request)
	{
		User::create($request->all());
		return view('registerSuccess');
		
	}
}
