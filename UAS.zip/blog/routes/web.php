<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('admin.users.index');
});

Route::get('/daftar', function () {
    return view('register');
});

Route::get('/jakarta', function () {
    return view('jakarta');
});

Route::get('/bogor', function () {
    return view('bogor');
});

Route::get('/tangerang', function () {
    return view('tangerang');
});

Route::get('/depok', function () {
    return view('depok');
});

Route::get('/bekasi', function () {
    return view('bekasi');
});
 Route::get('users', ['uses' => 'UsersController@index']);
 Route::get('users/create', ['uses' => 'UsersController@create']);
 Route::post('register',['uses' => 'UsersController@registerSuccess']);
 Route::post('users', ['uses' => 'UsersController@store']);
 Route::post('/loginMahasiswa', function () {
    return view('login-untuk-mahasiswa');
});
/*
Route::get('users', function(){
	$users = [
    	'0' => [
    		'first_name' => 'Andree',
    		'last_name' => 'Phanderson',
    		'location' => 'Jakarta'
    		],
    	'1' => [
    		'first_name' => 'Stephanie',
    		'last_name' => 'Budianto',
    		'location' => 'Jakarta'
    		]
    	];
    	return $users;
});*/