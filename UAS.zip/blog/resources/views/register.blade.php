<html>
	<head>
		<title>Daftar Wisata</title>
		<h1>Daftar</h1>
	</head>

	<body>
	<table>
	<form action="/register" method="POST">
{!! csrf_field() !!}
	<tr>
	<td>Nama Lengkap Tempat Wisata</td>
	<td>&nbsp;</td>
	<td><input type="text" name="namalengkap"></td>
	</tr>

	<tr>
	<td>Asal Wisata</td>
	<td>&nbsp;</td>
	<td><input type="text" name="asalwisata"></td>
	</tr>

	<tr>
	<td>Asal provinsi</td>
	<td>&nbsp;</td>
	<td><input type="text" name="asalprovinsi"></td>
	</tr>

	<tr>
	<td>Alamat Tempat Wisata</td>
	<td>&nbsp;</td>
	<td><input type="text" name="alamat"></td>
	</tr>

	<tr>
	<td>Nomor Telepon</td>
	<td>&nbsp;</td>
	<td><input type="text" name="nomortelepon"></td>
	</tr>

	<tr>
	<td>Biaya per masuk</td>
	<td>&nbsp;</td>
	<td><input type="text" name="biaya"></td>
	</tr>


	
	<tr>
	<td>Email</td>
	<td>&nbsp;</td>
	<td><input type="email" name="email"></td>
	</tr>

	<tr>
	<td>Password</td>
	<td>&nbsp;</td>
	<td><input type="password" name="password"></td>
	</tr>

	<tr>
	<td>Retype Password</td>
	<td>&nbsp;</td>
	<td><input type="password" name="password2"></td>
	</tr>

	<tr>
	<td colspan="2"> </td>
	<td>&nbsp;</td>
	<td><input type="submit" name="submit" value="Register"></td>
	</tr>

	</table></form>
	</body>

	

</html>