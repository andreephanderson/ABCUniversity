<html>
	<head>
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Welcome</title>

		<style type="text/css">

			html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
	.margin-left-20{
    margin-left: 20px;
	}
	.margin-top-40{
    margin-top: 40px;
    margin-bottom: 15px;
	}
	.margin-top-10{
    margin-top: 10px;
	}
	.font-size-1{
		font-size: 16pt;
	}
	.margin-left-550{
    margin-left: 550px;
	}

	</style>
	</head>

	<body>

</header>

            <div class="content">
                <p align="center" class="margin-top-40"><img src="Welcome.jpg" alt="Selamat Datang di Official Website Universitas ABC" name="Welcome" width="600" height="300" border="0"></p>

                
            </div>
        </div>
				
        <div id="pilihan_wisata" align="center">
				   <a href="jakarta" ><img src="jakarta.jpg" onMouseOut="this.src='jakarta.jpg'" onMouseOver="this.src='jakarta1.jpg'" alt="Jakarta" name="jakarta" width="120" height="50" border="0" class="rad"></a>
				   <a href="bogor" ><img src="bogor.jpg" onMouseOut="this.src='bogor.jpg'" onMouseOver="this.src='bogor1.jpg'" alt="Bogor" name="bogor" width="120" height="50" border="0" class="rad margin-left-20"></a>
				   <a href="tangerang" ><img src="tangerang.jpg" onMouseOut="this.src='tangerang.jpg'" onMouseOver="this.src='tangerang1.jpg'" alt="Tangerang" name="tangerang" width="120" height="50" border="0" class="rad margin-left-20"></a>
				   <a href="depok" ><img src="depok.jpg" onMouseOut="this.src='depok.jpg'" onMouseOver="this.src='depok1.jpg'" alt="Depok" name="depok" width="120" height="50" border="0" class="rad margin-left-20"></a>
				   <a href="bekasi" ><img src="bekasi.jpg" onMouseOut="this.src='bekasi.jpg'" onMouseOver="this.src='bekasi1.jpg'" alt="Bekasi" name="bekasi" width="120" height="50" border="0" class="rad margin-left-20"></a>
		</div>  
		<p align="center" class="margin-top-10"><img src="pembatas-login-register.jpg" name="pembatas" width="800" height="3" border="0"></p>
		
	</div>
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	<div align="center">
	<form action="/daftar" method="get">
	<p class="font-size-1">Tempat wisata anda belum terdaftar ?  
	<input class="btn btn-success" type="submit" value="Daftar"></p></form>
	</div>

</html>