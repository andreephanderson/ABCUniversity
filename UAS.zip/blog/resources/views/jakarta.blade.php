<html>
<head>
<title>Wisata Jakarta</title>
</head>

<body>
<ol><b>1. Monas</b><br><img src="monas.jpg" width="500px" height="300px"><br><p>Monas adalah tempat wisata di Jakarta yang paling populer, sekaligus pula salah satu kebanggaan Republik Indonesia. Monumen yang diarsiteki oleh Friedrich Silaban dan R.M. Soedarsono ini terbuka untuk umum setiap hari sejak jam 8 pagi hingga 3 sore, kecuali pada Senin pekan terakhir setiap bulannya ditutup untuk umum.<br>Tiket masuk Tugu Monas adalah sebesar Rp 5 ribu per orang (dewasa), mahasiswa Rp 3 ribu, dan anak-anak Rp 2 ribu. Untuk menggunakan lift ke puncak Monas, Anda dapat membayar tiket lift sebesar Rp 10 ribu per orang (dewasa) atau mahasiswa Rp 5 ribu.</p></ol>
<br><br>
<ol><b>2. Kepulauan Seribu</b><br><img src="kepulauanseribu.jpg" width="500px" height="300px"><br><p>Kepulauan Seribu, salah satu obyek wisata di Jakarta yang terdiri dari beberapa pulau kecil ini adalah spot menarik dari antara tempat wisata lain yang masuk propinsi DKI Jakarta.<br>Di Kepulauan Seribu, ada banyak aktivitas yang bisa Anda lakukan, mulai dari diving, snorkeling, atau sekedar berjalan-jalan menikmati sunset di kala senja. Ketersediaan sarana akomodasi yang baik di Kepulauan Seribu memudahkan pengunjung yang ingin lebih lama menkimati pengalaman wisatanya.</p></ol>
<br><br>
<ol><b>3. Taman Mini Indonesia Indah</b><br><img src="tmii.jpg" width="500px" height="300px"><br><p>Tak hanya populer bagi warga Jakarta, Taman Mini Indonesia Indah atau TMII adalah pula destinasi populer bagi pengunjung dari luar Jakarta yang ingin berwisata di Jakarta. Taman Mini Indonesia Indah adalah tempat wisata menarik di Jakarta yang cocok dinikmati bersama keluarga. Hal ini terbukti dari ribuan pengunjung memadati tempat wisata ini, mayoritas terdiri dari anak-anak, kaum muda, dan orang tua.</p></ol>
<br><br>
<ol><b>4. Ancol Dreamland</b><br><img src="ancol.jpg" width="500px" height="300px"><br><p>Sempat populer dengan nama Taman Impian Jaya Ancol, destinasi wisata yang satu ini kini lebih familiar disebut Ancol Dreamland. Boleh jadi Ancol Dreamland adalah icon wisata di Jakarta mengingat dalam setiap harinya, destinasi ini tak pernah sepi dari pengunjung baik domestik maupun mancanegara.<br>Adapun tiket masuk pintu gerbang Ancol adalah sebesar Rp 25 ribu serta tarif masuk kendaraan Rp 20 ribu (mobil) atau motor Rp 15 ribu.</p></ol>
<br><br>
<ol><b>5. Dunia Fantasi</b><br><img src="dufan.jpg" width="500px" height="300px"><br><p>Dufan atau Dunia Fantasi adalah obyek wisata populer di Jakarta yang temasuk bagian dari Ancol Dreamland atau Taman Impian Jaya Ancol. Sesungguhnya luas area Dunia Fantasi ini tidak begitu besar, hanya sekitar 9 hektar. Namun, di dalamnya terdapat berbagai wahana menarik yang siap memanjakan para pengunjung.<br>Dunia Fantasi terbagi menjadi beberapa spot dengan background negara-negara besar di dunia, seperti hal-hal bernuansa Eropa, Amerika, dan Indonesia sendiri. Uniknya masing-masing spot ini dilengkap sejumlah wahana bermain yang cukup lengkap, seperti kolam renang ukuran besar dan berbagai fasilitas hiburan.</p></ol>
</body>
</html>